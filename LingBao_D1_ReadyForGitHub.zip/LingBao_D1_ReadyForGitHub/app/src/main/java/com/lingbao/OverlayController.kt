
package com.lingbao

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayController(private val context: Context) {
    private var tv: TextView? = null
    private var wm: WindowManager? = null

    fun showTip(text: String) {
        if (wm == null) {
            wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 120
            }
            tv = TextView(context).apply {
                setBackgroundColor(0x99000000.toInt())
                setTextColor(Color.WHITE)
                textSize = 16f
                setPadding(24, 12, 24, 12)
            }
            wm?.addView(tv, params)
        }
        tv?.text = text
    }

    fun destroy() {
        try {
            wm?.removeView(tv)
        } catch (e: Exception) {}
        tv = null; wm = null
    }
}
