
package com.lingbao.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import com.lingbao.OverlayController
import com.lingbao.decision.DecisionEngine
import com.lingbao.logging.Logger
import com.lingbao.speech.TTSHelper

class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val overlay by lazy { OverlayController(this) }
    private val decision = DecisionEngine(this)
    private val logger = Logger(this)
    private val tts = TTSHelper(this)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundWithNotification()
        val resultCode = intent?.getIntExtra("resultCode", -1) ?: return START_NOT_STICKY
        val data: Intent = intent.getParcelableExtra("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)

        val dm = resources.displayMetrics
        imageReader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, android.graphics.PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay("lingbao_cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC, imageReader?.surface, null, null)

        imageReader?.setOnImageAvailableListener({ reader ->
            val image: Image? = reader.acquireLatestImage()
            if (image != null) {
                val bmp = imageToBitmap(image)
                image.close()
                if (bmp != null) {
                    overlay.showTip("灵宝：已监听，呼叫我说“灵宝”")
                }
            }
        }, Handler(Looper.getMainLooper()))

        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val channelId = "lingbao_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "LingBao", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(ch)
        }
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId).setContentTitle("灵宝").setContentText("后台监听中").setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        } else {
            Notification()
        }
        startForeground(2, notif)
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            Log.e("LingBao", "img2bmp error: ${e.message}")
            return null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { projection?.stop() } catch (_: Exception) {}
        overlay.destroy()
        tts.shutdown()
    }
}
