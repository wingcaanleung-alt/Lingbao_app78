
package com.lingbao.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class TTSHelper(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.CHINESE
        }
    }
    fun speak(text: String) {
        try {
            if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lingbao-${System.currentTimeMillis()}")
        } catch (e: Exception) { Log.e("LingBao", "TTS error: ${e.message}") }
    }
    fun shutdown() { try { tts?.shutdown() } catch (_: Exception) {} }
}
