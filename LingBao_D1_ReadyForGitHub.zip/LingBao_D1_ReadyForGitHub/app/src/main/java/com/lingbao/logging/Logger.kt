
package com.lingbao.logging

import android.content.Context
import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class Logger(private val ctx: Context) {
    private val dir = File(Environment.getExternalStorageDirectory(), "LingBao/logs")
    init { if (!dir.exists()) dir.mkdirs() }
    private val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)

    fun logEvent(event: String, obj: Map<String, Any?>) {
        try {
            val j = JSONObject(obj)
            j.put("ts", sdf.format(Date()))
            val out = File(dir, "events.log")
            val fw = FileWriter(out, true)
            fw.append(j.toString()).append("\n")
            fw.close()
        } catch (e: Exception) { e.printStackTrace() }
    }
}
