
package com.lingbao.decision

import android.content.Context

data class GameState(
    val goldDiff: Int = 0,
    val myAlive: Int = 5,
    val enemyAlive: Int = 5,
    val objective: String = "none",
    val gameTime: String = "00:00"
)

class DecisionEngine(private val ctx: Context) {
    // Simple rule-based decision, replace this file to upgrade AI logic.
    fun analyze(state: GameState): String {
        if (state.goldDiff < -2000) return "建议：经济落后，优先补刀守塔"
        if (state.goldDiff > 2000) return "建议：经济领先，寻找开团或控龙机会"
        return "建议：控线发育，注意视野"
    }
}
