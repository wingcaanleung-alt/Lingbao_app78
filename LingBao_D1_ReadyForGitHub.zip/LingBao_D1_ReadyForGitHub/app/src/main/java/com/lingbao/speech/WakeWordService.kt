
package com.lingbao.speech

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

class WakeWordService : Service() {
    private var sr: SpeechRecognizer? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        initRecognizer()
    }

    private fun initRecognizer() {
        try {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {}
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (matches != null && matches.isNotEmpty()) {
                        val text = matches[0].lowercase(Locale.getDefault())
                        if (text.contains("灵宝")) {
                            // Wake word detected - in production trigger full command pipeline
                            // Placeholder: log and speak acknowledgement
                            android.util.Log.i("LingBao", "Wake detected: $text")
                        }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = RecognizerIntent().apply {
                action = RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.CHINESE)
            }
            sr?.startListening(intent)
        } catch (e: Exception) {
            Log.e("LingBao", "Speech init error: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { sr?.destroy() } catch (_: Exception) {}
    }
}
